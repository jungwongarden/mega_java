package 클래스만들기;

public class 업그레이드계산기 {
	public int add(int x, int y) {
		return x + y;
	}
	
	public double add(int x, double y) {
		return x + y;
	}
	
	public double add(double x, double y) {
		return x + y;
	}
	
	public String add(String firstName, String lastName ) {
		return firstName + lastName;
	}
	
	public String add(String company, int field) {
		return company + field;
	}
	
	public int[] add() {
		int[] jumsu = {100, 99, 88};
		return jumsu;
	}
	
	
	
}
