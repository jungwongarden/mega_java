package 클래스만들기;

public class Test {

	public static void main(String[] args) {
		System.out.println("나는 한글이야.");
		System.out.println("나는 한글이야2.");
		//반영하다.(commit)
	}

}
