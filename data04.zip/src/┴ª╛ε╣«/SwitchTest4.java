package ���;

import java.util.Date;

public class SwitchTest4 {

	public static void main(String[] args) {
		char c = 'A';
		
		switch (c) {
		case 'A':
			System.out.println("�ֿ��!"); break;
		case 'B':
			System.out.println("���!"); break;
		default:
			System.out.println("����");
		}
	}
}
